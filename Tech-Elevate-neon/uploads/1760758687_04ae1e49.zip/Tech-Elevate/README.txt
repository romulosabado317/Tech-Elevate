Tech-Elevate-Neon-Full
----------------------

1) Start XAMPP (Apache + MySQL).
2) Import the SQL file:
   - Open http://localhost/phpmyadmin
   - Import the file: /database/tech_elevate.sql
3) Copy the folder to C:\xampp\htdocs\ if not already there.
4) Ensure uploads/ and uploads/profile_photos/ are writable by PHP (the app creates them).
5) Visit: http://localhost/Tech-Elevate-Neon-Full/ or folder name used.
Seeded accounts:
 - Admin: tech@gmail.com / admin123
 - Student: group1@gmail.com / demo123

Notes:
- The projects table includes a 'status' column (active/inactive).
- Explore page shows only active projects.
- Admin can mark projects inactive from the admin dashboard.
