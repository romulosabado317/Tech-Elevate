<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$basePath = "/Tech-Elevate";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Tech Elevate — Purple Neon Edition</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo $basePath; ?>/assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="logo-wrap">
    <a href="<?php echo $basePath; ?>/index.php" class="logo-link" aria-label="Tech Elevate Home">
      <svg width="160" height="46" viewBox="0 0 320 92" xmlns="http://www.w3.org/2000/svg" class="logo-svg">
        <defs>
          <linearGradient id="g" x1="0" x2="1">
            <stop offset="0" stop-color="#a855f7"/>
            <stop offset="1" stop-color="#d946ef"/>
          </linearGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        <g filter="url(#glow)">
          <text x="8" y="60" font-family="Arial, Helvetica, sans-serif" font-size="50" fill="url(#g)" style="font-weight:700;">
            Tech<span style="fill:rgba(255,255,255,0.04)"> </span>Elevate
          </text>
        </g>
      </svg>
    </a>
  </div>
  <nav class="top-nav">
    <?php if (isset($_SESSION['user_id'])): ?>
      <a href="<?php echo $basePath; ?>/dashboard.php">Dashboard</a>
      <a href="<?php echo $basePath; ?>/explore.php">Explore</a>
      <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="<?php echo $basePath; ?>/admin/dashboard.php">Admin</a>
      <?php endif; ?>
      <a href="<?php echo $basePath; ?>/logout.php">Logout</a>
    <?php else: ?>
      <a href="<?php echo $basePath; ?>/index.php">Home</a>
      <a href="<?php echo $basePath; ?>/login.php">Login</a>
      <a href="<?php echo $basePath; ?>/register.php">Register</a>
    <?php endif; ?>
  </nav>
</header>
<main class="page-body">
