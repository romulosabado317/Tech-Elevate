CREATE DATABASE IF NOT EXISTS tech_elevate;
USE tech_elevate;

CREATE TABLE IF NOT EXISTS users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('student','admin') NOT NULL DEFAULT 'student',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  course VARCHAR(150) DEFAULT NULL,
  year_level VARCHAR(100) DEFAULT NULL,
  about TEXT DEFAULT NULL,
  photo VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS projects (
  id INT(11) NOT NULL AUTO_INCREMENT,
  user_id INT(11) NOT NULL,
  project_title VARCHAR(255) NOT NULL,
  project_description TEXT,
  filename VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (name, email, password, role, status, photo) VALUES
('Tech Admin', 'tech@gmail.com', MD5('admin123'), 'admin', 'active', 'admin_profile.jpg'),
('Student Group 1', 'group1@gmail.com', MD5('demo123'), 'student', 'active', 'student_profile.jpg');

INSERT INTO projects (user_id, project_title, project_description, filename, status) VALUES
(2, 'Sample Project', 'This is an example active project.', 'sample_project.docx', 'active'),
(2, 'Inactive Demo Project', 'This project is currently marked inactive.', 'inactive_demo.txt', 'inactive');
