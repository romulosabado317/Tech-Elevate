Tech-Elevate Safe Package
-------------------------
This package contains the Tech-Elevate website with PHP files renamed to .phps to avoid antivirus blocking.

Steps to use:
1. Extract this ZIP into: C:\xampp\htdocs\Tech-Elevate-Safe\
2. Rename all files with extension .phps back to .php 
   - You can do this in PowerShell (run as admin) from the folder:
     Get-ChildItem -Recurse -Filter *.phps | Rename-Item -NewName {$_.Name -replace '\.phps$','.php'}
3. Start XAMPP (Apache + MySQL).
4. Import the database file: /database/tech_elevate.sql into phpMyAdmin.
5. Visit http://localhost/Tech-Elevate-Safe/

Seeded credentials:
  Admin: tech@gmail.com / admin123
  Student: group1@gmail.com / demo123

Notes:
- Do NOT open .phps files in a browser directly. Rename them to .php first.
- The CSS, assets, and SQL are included and unchanged.
